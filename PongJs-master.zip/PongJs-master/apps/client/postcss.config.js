module.exports = {
  plugins: {
    tailwindcss: { config: './apps/client/tailwind.config.js' },
    autoprefixer: {},
  },
};
